#!/bin/bash
reldir=`dirname $0`
cd $reldir
java -jar flosc/flosc_2_0_3.jar 3333 3000