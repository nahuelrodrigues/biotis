FLOSC is used only if running a Flash Application.

Requirements: Java Runtime 6+ http://java.com/en/download/