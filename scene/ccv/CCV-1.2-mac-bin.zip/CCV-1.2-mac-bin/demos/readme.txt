To run the photo demo:

requirments: Flash 9+. The flash standalone player can be downloaded here: http://www.adobe.com/support/flashplayer/downloads.html

1) Add the demo directory to your flash global security settings: http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager04.html

2) Launch the FLOSC Gateway script in the terminal.

3) Open tbeta and send TUIO.

4) Launch the Photo Demo